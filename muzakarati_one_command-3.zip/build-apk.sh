#!/usr/bin/env bash
set -e

echo "==> تثبيت الحزم..."
npm install

echo "==> تجهيز Android..."
if [ ! -d android ]; then
  npx cap add android
fi

echo "==> مزامنة المشروع..."
npx cap sync android

echo "==> بناء APK..."
cd android
chmod +x gradlew
./gradlew assembleDebug

echo
echo "=========================================="
echo "تم بناء APK بنجاح!"
echo "المسار:"
echo "android/app/build/outputs/apk/debug/app-debug.apk"
echo "=========================================="
