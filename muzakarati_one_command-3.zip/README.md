# مذاكرتي — بناء APK بأمر واحد

## في GitHub Codespaces

افتح Terminal ثم نفّذ:

```bash
npm run apk
```

بعد انتهاء البناء ستجد الملف هنا:

`android/app/build/outputs/apk/debug/app-debug.apk`

يمكنك أيضًا تشغيل:

```bash
./build-apk.sh
```
