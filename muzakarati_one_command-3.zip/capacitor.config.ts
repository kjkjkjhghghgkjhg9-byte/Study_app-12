import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.muzakarati.app',
  appName: 'مذاكرتي',
  webDir: 'www'
};

export default config;
